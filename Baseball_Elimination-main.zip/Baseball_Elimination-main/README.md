# Baseball_Elimination
Coursera Algorithm assignment of Baseball Elimination problem

Using maxflow graph algorithm

Code description: https://coursera.cs.princeton.edu/algs4/assignments/baseball/specification.php
